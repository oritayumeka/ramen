$('#password').hide();
$('#button').hide();

$('#delete').on('click', function () { // 選択肢変更時
		$('#password').show();
		$('#button').show();
		});